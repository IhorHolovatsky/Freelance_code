﻿namespace CNA_Scraper.Enums
{
    public enum Command
    {
        SearchAgents,
        ScrapAgents,
        NextPage
    }
}